// A simple HTTP server without EdgeDB dependencies
const http = require('http');
const fs = require('fs');
const path = require('path');

// Global error handler
process.on('uncaughtException', (err) => {
  console.error('UNCAUGHT EXCEPTION:', err);
  console.error(err.stack);
});

console.log('=======================================');
console.log('Starting EdgeDB Test Server');
console.log('=======================================');

// Read from .env file if available
function loadEnvFromDotEnv() {
  try {
    const envFilePath = path.join(process.cwd(), '.env');
    console.log('Checking for .env file at:', envFilePath);
    
    if (fs.existsSync(envFilePath)) {
      console.log('Loading environment variables from .env file:', envFilePath);
      const content = fs.readFileSync(envFilePath, 'utf8');
      console.log('ENV file content length:', content.length);
      const lines = content.split('\n');
      console.log('ENV file lines:', lines.length);
      
      lines.forEach(line => {
        if (line.trim() === '') return;
        console.log('Processing .env line:', line);
        const matches = line.match(/^\s*([\w.-]+)\s*=\s*(.*)?\s*$/);
        if (matches) {
          const key = matches[1];
          let value = matches[2] || '';
          if (value.startsWith('"') && value.endsWith('"')) {
            value = value.substring(1, value.length - 1);
          }
          process.env[key] = value;
          console.log(`Set env var: ${key}=${key.includes('DATABASE') ? value.replace(/:.+@/, ':***@') : value}`);
        } else {
          console.log('Invalid .env line format:', line);
        }
      });
      
      console.log('Loaded environment variables from .env file');
    } else {
      console.log('No .env file found at:', envFilePath);
    }
  } catch (error) {
    console.error('Error loading .env file:', error);
  }
}

// Helper function to safely mask a URL
function maskUrl(url) {
  if (!url) return 'Not available';
  return url.replace(/:.+@/, ':***@');
}

// Print current environment variables
function printEnvVars() {
  console.log('\n--- Current Environment Variables ---');
  console.log('DATABASE_URL:', maskUrl(process.env.DATABASE_URL || 'Not set'));
  console.log('PORT:', process.env.PORT || 'Not set');
  console.log('NODE_ENV:', process.env.NODE_ENV || 'Not set');
  console.log('-----------------------------------\n');
}

// Must be called before anything else
console.log('Loading environment variables...');
loadEnvFromDotEnv();
printEnvVars();

// Ensure we have a port
const PORT = process.env.PORT || 5000;
console.log('Using PORT:', PORT);

// Create the server
const server = http.createServer((req, res) => {
  try {
    // Get the connection URL from the environment variable (for display only)
    const databaseUrl = process.env.DATABASE_URL || 'No database URL provided';
    
    // Log the request
    console.log(new Date().toISOString() + ' - ' + req.method + ' ' + req.url);
    
    // Log environment variables we have
    console.log('Environment vars: PORT=', process.env.PORT);
    console.log('Environment vars: DATABASE_URL=', maskUrl(databaseUrl));
    
    // Send a response
    res.statusCode = 200;
    res.setHeader('Content-Type', 'text/plain');
    res.end('\nEdgeDB Test Server\n-----------------\nServer is running on port ' + PORT + 
            '\nDatabase URL (masked): ' + maskUrl(databaseUrl) + 
            '\nRequest: ' + req.method + ' ' + req.url + 
            '\nNode.js version: ' + process.version + 
            '\nCurrent working directory: ' + process.cwd() + 
            '\nEnvironment: ' + (process.env.NODE_ENV || 'Not set') + '\n  ');
  } catch (err) {
    console.error('Error handling request:', err);
    res.statusCode = 500;
    res.end('Server Error: ' + err.message);
  }
});

// Start the server
console.log('Starting server on port', PORT);
server.listen(PORT, () => {
  console.log('Server started on port ' + PORT);
  console.log('Node.js version: ' + process.version);
  console.log('Database URL (masked): ' + maskUrl(process.env.DATABASE_URL || 'Not provided'));
  console.log('Current working directory: ' + process.cwd());
  console.log('Server is ready to accept connections!');
}); 
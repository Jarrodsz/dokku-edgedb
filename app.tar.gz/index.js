const { createClient } = require("edgedb");

// Use environment variables from Dokku service linking
const getDatabaseUrl = () => {
  // First try DATABASE_URL which is the standard environment variable from Dokku service links
  if (process.env.DATABASE_URL) {
    console.log("Using DATABASE_URL environment variable");
    return process.env.DATABASE_URL;
  }
  
  // Fall back to GEL_URL if it exists
  if (process.env.GEL_URL) {
    console.log("Using GEL_URL environment variable");
    return process.env.GEL_URL;
  }

  // Default connection for local development
  console.log("Using default local connection");
  return null; // Let edgedb client use default connection method
};

async function main() {
  try {
    console.log("Attempting to connect to EdgeDB...");
    
    // Create client with connection string from environment or default
    const client = createClient(getDatabaseUrl());
    
    // Test connection with a simple query
    console.log("Running test query...");
    const result = await client.query(`SELECT 'Connection to EdgeDB successful!';`);
    
    console.log("Query result:", result);
    
    // Get EdgeDB server version
    const version = await client.query(`SELECT sys::get_version_as_str();`);
    console.log("EdgeDB version:", version[0]);
    
    // Close the connection
    await client.close();
    
    console.log("Connection test completed successfully!");
  } catch (error) {
    console.error("Error connecting to EdgeDB:", error);
    process.exit(1);
  }
}

// Set up an HTTP server to keep the process running and see logs
const http = require('http');
const PORT = process.env.PORT || 8080;

const server = http.createServer((req, res) => {
  res.statusCode = 200;
  res.setHeader('Content-Type', 'text/plain');
  res.end('EdgeDB Connection Test App\n');
});

server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  main().catch(console.error);
}); 
// A minimal HTTP server with no dependencies and no environment variable loading
const http = require('http');

// Print startup message
console.log('Starting Mini HTTP Server');

// Create the server
const server = http.createServer((req, res) => {
  const now = new Date().toISOString();
  console.log(`${now} - Request: ${req.method} ${req.url}`);
  
  // Send a response
  res.statusCode = 200;
  res.setHeader('Content-Type', 'text/plain');
  res.end(`
Mini EdgeDB Test Server
----------------------
Server is running on port 3000
Request: ${req.method} ${req.url}
Node.js version: ${process.version}
Timestamp: ${now}
`);
});

// Start the server on a fixed port
const PORT = 3000;
server.listen(PORT, () => {
  console.log(`Server started on port ${PORT}`);
  console.log(`Node.js version: ${process.version}`);
  console.log('Server ready!');
}); 
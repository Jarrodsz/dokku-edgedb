#!/bin/bash
set -e

# Create a temporary directory for the deployment
TEMP_DIR=$(mktemp -d)
ARCHIVE_NAME="app.tar.gz"

echo "🚀 Deploying application to Dokku..."
echo "Preparing application files..."

# Copy application files to the temporary directory
cp -r index.js package.json package-lock.json Procfile $TEMP_DIR

echo "Creating archive..."
tar -czf $ARCHIVE_NAME -C $TEMP_DIR .
rm -rf $TEMP_DIR

echo "Copying to Dokku container..."
/Applications/Docker.app/Contents/Resources/bin/docker cp $ARCHIVE_NAME dokku-gel-dev:/tmp/$ARCHIVE_NAME

echo "Deploying to Dokku..."
/Applications/Docker.app/Contents/Resources/bin/docker exec -it dokku-gel-dev bash -c "
  mkdir -p /home/dokku/edgedb-test-app
  tar -xzf /tmp/$ARCHIVE_NAME -C /home/dokku/edgedb-test-app
  cd /home/dokku/edgedb-test-app
  echo '{ \"scripts\": { \"start\": \"node index.js\" } }' > package.json 
  echo 'Running the application...'
  DATABASE_URL=\$(dokku gel:info edge-db-instance --dsn)
  echo \"DATABASE_URL=\$DATABASE_URL\" > .env
  echo 'Starting the application with DATABASE_URL configured...'
  npm start
"

echo "Cleaning up..."
rm $ARCHIVE_NAME

echo "✅ Deployment completed!" 
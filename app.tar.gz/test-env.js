// A simple test script to check environment variables
const fs = require('fs');
const path = require('path');

console.log('===== Environment Test =====');
console.log('Node version:', process.version);
console.log('Current directory:', process.cwd());

// Try to load from .env
console.log('\n----- .env file check -----');
const envPath = path.join(process.cwd(), '.env');
if (fs.existsSync(envPath)) {
  console.log('.env file exists at:', envPath);
  console.log('Contents:');
  const contents = fs.readFileSync(envPath, 'utf8');
  console.log(contents);
} else {
  console.log('No .env file found at:', envPath);
}

// Check current environment vars
console.log('\n----- Environment Variables -----');
console.log('DATABASE_URL:', process.env.DATABASE_URL || 'Not set');
console.log('PORT:', process.env.PORT || 'Not set');
console.log('NODE_ENV:', process.env.NODE_ENV || 'Not set');

// Check for any env vars containing certain keywords
console.log('\n----- All Related Environment Variables -----');
Object.keys(process.env).forEach(key => {
  if (key.includes('DATABASE') || key.includes('PORT') || key.includes('NODE') || key.includes('ENV')) {
    // Mask sensitive information
    let value = process.env[key];
    if (key.includes('DATABASE') && value && value.includes('@')) {
      value = value.replace(/:.+@/, ':***@');
    }
    console.log(`${key}:`, value);
  }
}); 